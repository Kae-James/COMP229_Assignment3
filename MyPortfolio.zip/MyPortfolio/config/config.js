const config = {
  env: process.env.NODE_ENV || 'development',
  port: process.env.PORT || 3000,

  // Secret key used to sign JWT tokens
  jwtSecret: process.env.JWT_SECRET || 'superDuperRandomSecret12345',

 // Connection string for Portfolio database
  mongoUri:
    process.env.MONGODB_URI ||
    'mongodb+srv://kjames50_db_user:<<PASSWORD PLACEHOLDER>>@cluster0.olonkzq.mongodb.net/Portfolio',

  // Hardcoded Admin account – created in MongoDB automatically on server start
  // (see server/helpers/seed.js). Every other account signs up with role "user".
  admin: {
    name: 'Portfolio Admin',
    email: process.env.ADMIN_EMAIL || 'admin@portfolio.com',
    password: process.env.ADMIN_PASSWORD || '<<PASSWORD PLACEHOLDER>>'
  }
}

export default config
