import User from '../models/user.model.js'
import jwt from 'jsonwebtoken'
import { expressjwt } from 'express-jwt'
import config from './../../config/config.js'

// POST /auth/signin - check email + password, return a signed JWT
const signin = async (req, res) => {
  try {
    const user = await User.findOne({ email: req.body.email })
    if (!user) return res.status(401).json({ error: 'User not found' })

    if (!user.authenticate(req.body.password)) {
      return res.status(401).json({ error: "Email and password don't match." })
    }

    const token = jwt.sign({ _id: user._id, role: user.role }, config.jwtSecret, { expiresIn: '1d' })
    res.cookie('t', token, { expires: new Date(Date.now() + 9999 * 1000) })

    return res.json({
      token,
      user: { _id: user._id, name: user.name, email: user.email, role: user.role }
    })
  } catch (err) {
    return res.status(401).json({ error: 'Could not sign in' })
  }
}

// GET /auth/signout - clear the token cookie
const signout = (req, res) => {
  res.clearCookie('t')
  return res.status(200).json({ message: 'signed out' })
}

// Authentication: request must carry a valid token in "Authorization: Bearer <token>"
// On success the decoded token ({ _id, role }) is placed on req.auth
const requireSignin = expressjwt({
  secret: config.jwtSecret,
  algorithms: ['HS256'],
  requestProperty: 'auth'
})

// Authorization (role check): only an Admin may continue.
// The role is re-read from the database so a changed/forged token role is never trusted.
const isAdmin = async (req, res, next) => {
  try {
    const user = await User.findById(req.auth && req.auth._id).select('role')
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ error: 'Admin access required' })
    }
    next()
  } catch (err) {
    return res.status(403).json({ error: 'Admin access required' })
  }
}

// Authorization: signed-in user may only read/change their OWN user record (Admin may change any)
const hasAuthorization = async (req, res, next) => {
  const isOwner =
    req.profile && req.auth && req.profile._id.toString() === req.auth._id
  if (isOwner) return next()
  const me = await User.findById(req.auth && req.auth._id).select('role')
  if (me && me.role === 'admin') return next()
  return res.status(403).json({ error: 'User is not authorized' })
}

export default { signin, signout, requireSignin, isAdmin, hasAuthorization }
