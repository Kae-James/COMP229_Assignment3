import mongoose from 'mongoose'

const ContactSchema = new mongoose.Schema({
  firstname: { type: String, trim: true, required: 'First name is required' },
  lastname:  { type: String, trim: true, required: 'Last name is required' },
  email: {
    type: String, trim: true, required: 'Email is required',
    match: [/.+\@.+\..+/, 'Please fill a valid email address']
  },
  phone:   { type: String, trim: true },
  message: { type: String, trim: true },
  created: { type: Date, default: Date.now }
})

export default mongoose.model('Contact', ContactSchema)
