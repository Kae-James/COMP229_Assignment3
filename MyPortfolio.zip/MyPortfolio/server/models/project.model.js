import mongoose from 'mongoose'

const ProjectSchema = new mongoose.Schema({
  title:        { type: String, trim: true, required: 'Title is required' },
  firstname:    { type: String, trim: true },
  lastname:     { type: String, trim: true },
  email:        { type: String, trim: true },
  completion:   { type: Date },
  description:  { type: String, trim: true },
  // extra display fields for the portfolio Projects page
  technologies: { type: String, trim: true },
  role:         { type: String, trim: true }
})

export default mongoose.model('Project', ProjectSchema)
