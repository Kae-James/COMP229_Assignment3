import config from '../../config/config.js'
import User from '../models/user.model.js'
import Project from '../models/project.model.js'
import Qualification from '../models/qualification.model.js'

// Creates the hardcoded Admin account (and starter portfolio content) if missing.
export const seedDatabase = async () => {
  try {
    const { name, email, password } = config.admin
    const existing = await User.findOne({ email })
    if (!existing) {
      await new User({ name, email, password, role: 'admin' }).save()
      console.log(`Admin account created: ${email}`)
    } else if (existing.role !== 'admin') {
      existing.role = 'admin'
      await existing.save()
      console.log(`Admin role restored for: ${email}`)
    }

    const owner = { firstname: 'Kaelyn', lastname: 'James', email: 'kjames50@my.centennialcollege.ca' }

    if ((await Project.countDocuments()) === 0) {
      await Project.insertMany([
        { ...owner, title: 'Restaurant Online Ordering Platform', technologies: 'HTML, CSS, JavaScript',
          role: 'Frontend Developer', completion: new Date('2025-12-15'),
          description: 'Designed and built a responsive web application for a restaurant to display menus and capture digital dish orders. Implemented client-side validation and responsive image galleries.' },
        { ...owner, title: 'Retail Inventory Database System', technologies: 'SQL, Relational Databases',
          role: 'Team Lead & Database Developer', completion: new Date('2025-12-10'),
          description: 'Co-developed an SQL database for store managers to update and track inventory across departments. Led a group of 3, tracking Agile milestones and executing QA testing.' },
        { ...owner, title: 'Pet Rescue & Adoption Platform (SRS)', technologies: 'Agile, UML, System Architecture',
          role: 'Software Requirements Specialist', completion: new Date('2026-04-20'),
          description: 'Collaborated in an Agile team to author a complete Software Requirements Specification (SRS) document, defining structural UML diagrams and functional requirements.' }
      ])
      console.log('Starter projects added')
    }

    if ((await Qualification.countDocuments()) === 0) {
      await Qualification.insertMany([
        { ...owner, title: 'Software Engineering Technology - Artificial Intelligence (Advanced Diploma)',
          completion: new Date('2028-04-30'),
          description: 'Centennial College, Toronto, ON (Sept 2025 - Present). GPA: 4.3 / 4.5 (A). Relevant Courses: Web Application Development, Web Interface Design, Client-Side Web Development, Java Programming, C# Programming, Unix/Linux OS, AI Foundation, AI Systems Design, Software Requirements Engineering.' },
        { ...owner, title: 'B1 French DELF (Diplôme d’Études en Langue Française)', completion: new Date('2025-06-01'),
          description: 'French Ministry of Education – Certified 2025' },
        { ...owner, title: 'Standard First Aid CPR/AED Level C', completion: new Date('2024-07-01'),
          description: 'Action First Aid – Completed 2024' },
        { ...owner, title: 'Arts & Culture SHSM (Specialist High Skills Major)', completion: new Date('2025-06-01'),
          description: 'Bishop Tonnos Catholic Secondary School – Certified 2025' }
      ])
      console.log('Starter qualifications added')
    }
  } catch (err) {
    console.error('Seeding failed:', err.message)
  }
}
