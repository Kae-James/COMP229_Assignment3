const getErrorMessage = (err) => {
  let message = ''
  if (err.code) {
    switch (err.code) {
      case 11000:
      case 11001:
        message = getUniqueErrorMessage(err); break
      default:
        message = 'Something went wrong'
    }
  } else {
    for (let errName in err.errors) {
      if (err.errors[errName].message) message = err.errors[errName].message
    }
  }
  return message
}

const getUniqueErrorMessage = (err) => {
  // Works out which unique field (e.g. email) caused the duplicate-key error
  let field = err.keyValue && Object.keys(err.keyValue)[0]
  if (!field) {
    const match = /index:\s*(?:\S+\.\$)?([A-Za-z]+)_\d/.exec(err.message || '')
    field = match ? match[1] : 'email'
  }
  return field.charAt(0).toUpperCase() + field.slice(1) + ' already exists'
}

export default { getErrorMessage }