import express from 'express'
import userCtrl from '../controllers/user.controller.js'
import authCtrl from '../controllers/auth.controller.js'

const router = express.Router()

router.route('/api/users')
  .get(authCtrl.requireSignin, authCtrl.isAdmin, userCtrl.list)             // get all users (Admin)
  .post(userCtrl.create)                                                    // sign up (public, role = user)
  .delete(authCtrl.requireSignin, authCtrl.isAdmin, userCtrl.removeAll)     // remove all users (Admin)

router.route('/api/users/:userId')
  .get(authCtrl.requireSignin, authCtrl.hasAuthorization, userCtrl.read)    // own account or Admin
  .put(authCtrl.requireSignin, authCtrl.hasAuthorization, userCtrl.update)  // own account or Admin
  .delete(authCtrl.requireSignin, authCtrl.hasAuthorization, userCtrl.remove)

router.param('userId', userCtrl.userByID)

export default router
