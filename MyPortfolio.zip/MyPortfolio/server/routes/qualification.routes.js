import express from 'express'
import qualificationCtrl from '../controllers/qualification.controller.js'
import authCtrl from '../controllers/auth.controller.js'

const router = express.Router()

// Everyone can view (read). Only a signed-in Admin can create / update / delete.
router.route('/api/qualifications')
  .get(qualificationCtrl.list)                                                    // get all qualifications
  .post(authCtrl.requireSignin, authCtrl.isAdmin, qualificationCtrl.create)       // add new qualification
  .delete(authCtrl.requireSignin, authCtrl.isAdmin, qualificationCtrl.removeAll)  // remove all qualifications

router.route('/api/qualifications/:qualificationId')
  .get(qualificationCtrl.read)                                                    // get qualification by id
  .put(authCtrl.requireSignin, authCtrl.isAdmin, qualificationCtrl.update)        // update qualification by id
  .delete(authCtrl.requireSignin, authCtrl.isAdmin, qualificationCtrl.remove)     // remove qualification by id

router.param('qualificationId', qualificationCtrl.qualificationByID)

export default router
