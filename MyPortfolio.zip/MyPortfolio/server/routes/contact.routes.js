import express from 'express'
import contactCtrl from '../controllers/contact.controller.js'
import authCtrl from '../controllers/auth.controller.js'

const router = express.Router()

// Anyone can send a message through the Contact form (POST).
// Messages are private, so reading / updating / deleting them is Admin only.
router.route('/api/contacts')
  .get(authCtrl.requireSignin, authCtrl.isAdmin, contactCtrl.list)          // get all contacts
  .post(contactCtrl.create)                                                 // add new contact
  .delete(authCtrl.requireSignin, authCtrl.isAdmin, contactCtrl.removeAll)  // remove all contacts

router.route('/api/contacts/:contactId')
  .get(authCtrl.requireSignin, authCtrl.isAdmin, contactCtrl.read)          // get contact by id
  .put(authCtrl.requireSignin, authCtrl.isAdmin, contactCtrl.update)        // update contact by id
  .delete(authCtrl.requireSignin, authCtrl.isAdmin, contactCtrl.remove)     // remove contact by id

router.param('contactId', contactCtrl.contactByID)

export default router
