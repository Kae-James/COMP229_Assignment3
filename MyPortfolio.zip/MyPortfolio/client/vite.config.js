import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// The dev server forwards API calls to the Express backend on port 3000
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api':  { target: 'http://localhost:3000', changeOrigin: true },
      '/auth': { target: 'http://localhost:3000', changeOrigin: true }
    }
  }
})
