import React from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from './AuthContext.jsx'

// Protected route: only an Admin can open the wrapped page
export default function AdminRoute({ children }) {
  const { isSignedIn, isAdmin } = useAuth()
  const location = useLocation()
  if (!isSignedIn) return <Navigate to="/signin" replace state={{ from: location }} />
  if (!isAdmin) return <Navigate to="/" replace />
  return children
}
