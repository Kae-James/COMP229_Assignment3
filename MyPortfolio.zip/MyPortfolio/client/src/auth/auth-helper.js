// Keeps the JWT + signed-in user in sessionStorage so a page refresh keeps you signed in
const KEY = 'jwt'

const auth = {
  authenticate(jwt) {
    if (typeof window !== 'undefined') sessionStorage.setItem(KEY, JSON.stringify(jwt))
  },
  isAuthenticated() {
    if (typeof window === 'undefined') return false
    const stored = sessionStorage.getItem(KEY)
    return stored ? JSON.parse(stored) : false
  },
  clearJWT() {
    if (typeof window !== 'undefined') sessionStorage.removeItem(KEY)
  }
}

export default auth
