import React, { createContext, useContext, useState } from 'react'
import auth from './auth-helper.js'
import * as api from '../lib/api.js'

// Global auth state: who is signed in and whether they are an Admin
const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [session, setSession] = useState(() => auth.isAuthenticated() || null)

  const signin = async (credentials) => {
    const data = await api.signin(credentials)   // { token, user }
    auth.authenticate(data)
    setSession(data)
    return data.user
  }

  const signout = async () => {
    try { await api.signout() } catch (e) { /* still clear locally */ }
    auth.clearJWT()
    setSession(null)
  }

  const user = session ? session.user : null
  const value = { user, isSignedIn: !!user, isAdmin: user?.role === 'admin', signin, signout }
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => useContext(AuthContext)
