import React, { useState } from 'react';
import { qualificationsApi } from '../lib/api';
import useCrud from '../lib/useCrud';
import { useAuth } from '../auth/AuthContext';
import QualificationForm from '../components/QualificationForm';
import { toDisplayDate } from '../lib/format';

export default function Education() {
  const { isAdmin } = useAuth();
  const { items, loading, error, create, update, remove, removeAll } = useCrud(qualificationsApi);
  const [editing, setEditing] = useState(null);
  const [notice, setNotice] = useState('');

  const save = async (data) => {
    const ok = editing ? await update(editing._id, data) : await create(data);
    if (ok) { setNotice(editing ? 'Qualification updated.' : 'Qualification added.'); setEditing(null); }
    return ok;
  };

  const del = async (q) => {
    if (await remove(q._id)) setNotice(`Deleted "${q.title}".`);
  };

  const delAll = async () => {
    if (window.confirm('Delete ALL qualifications?') && await removeAll()) setNotice('All qualifications deleted.');
  };

  return (
    <div className="page-container education-page">
      <h2>Education & Qualifications</h2>

      {isAdmin && (
        <div className="admin-panel">
          <QualificationForm initial={editing} onSave={save} onCancel={() => setEditing(null)} />
        </div>
      )}

      {notice && <p className="alert alert-success">{notice}</p>}
      {error && <p className="alert alert-error">{error}</p>}
      {loading && <p>Loading…</p>}
      {!loading && items.length === 0 && <p>No qualifications yet.</p>}

      <div className="education-list">
        {items.map((q) => (
          <div key={q._id} className="education-card">
            <h3>{q.title}</h3>
            {q.completion && <span className="education-date">Completion: {toDisplayDate(q.completion)}</span>}
            {q.description && <p>{q.description}</p>}
            {(q.firstname || q.email) && (
              <p className="meta">{[q.firstname, q.lastname].filter(Boolean).join(' ')} {q.email && `· ${q.email}`}</p>
            )}
            {isAdmin && (
              <div className="card-actions">
                <button className="btn btn-small" onClick={() => { setEditing(q); window.scrollTo(0, 0); }}>Edit</button>
                <button className="btn btn-small btn-danger" onClick={() => del(q)}>Delete</button>
              </div>
            )}
          </div>
        ))}
      </div>

      {isAdmin && items.length > 0 && (
        <button className="btn btn-danger delete-all" onClick={delAll}>Delete All Qualifications</button>
      )}
    </div>
  );
}
