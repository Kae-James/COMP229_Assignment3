import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { signup } from '../lib/api';

export default function Signup() {
  const [serverError, setServerError] = useState('');
  const [success, setSuccess] = useState(false);
  const { register, handleSubmit, watch, reset, formState: { errors, isSubmitting } } = useForm();

  const onSubmit = async ({ name, email, password }) => {
    setServerError('');
    try {
      await signup({ name, email, password });   // saved to MongoDB with role "user"
      setSuccess(true);
      reset();
    } catch (err) {
      setServerError(err.message);
    }
  };

  if (success) {
    return (
      <div className="page-container auth-page">
        <h2>Account Created</h2>
        <p className="alert alert-success">New account successfully created. You can now sign in.</p>
        <Link to="/signin" className="btn">Go to Sign In</Link>
      </div>
    );
  }

  return (
    <div className="page-container auth-page">
      <h2>Sign Up</h2>
      <form onSubmit={handleSubmit(onSubmit)} className="contact-form" noValidate>
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input id="name" {...register('name', { required: 'Name is required' })} />
          {errors.name && <span className="error">{errors.name.message}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input id="email" type="email" {...register('email', {
            required: 'Email is required',
            pattern: { value: /.+@.+\..+/, message: 'Please enter a valid email address' }
          })} />
          {errors.email && <span className="error">{errors.email.message}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input id="password" type="password" {...register('password', {
            required: 'Password is required',
            minLength: { value: 6, message: 'Password must be at least 6 characters' }
          })} />
          {errors.password && <span className="error">{errors.password.message}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="confirm">Confirm Password:</label>
          <input id="confirm" type="password" {...register('confirm', {
            validate: (v) => v === watch('password') || 'Passwords do not match'
          })} />
          {errors.confirm && <span className="error">{errors.confirm.message}</span>}
        </div>
        {serverError && <p className="alert alert-error">{serverError}</p>}
        <button type="submit" className="btn" disabled={isSubmitting}>
          {isSubmitting ? 'Creating account…' : 'Sign Up'}
        </button>
      </form>
      <p className="auth-switch">Already have an account? <Link to="/signin">Sign in</Link></p>
    </div>
  );
}
