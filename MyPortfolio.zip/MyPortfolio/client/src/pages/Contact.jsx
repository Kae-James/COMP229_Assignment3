import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form'; // Form state management
import { contactsApi } from '../lib/api';

export default function Contact() {
  const navigate = useNavigate();
  const [serverError, setServerError] = useState('');
  const [sent, setSent] = useState(false);
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm();

  const onSubmit = async (data) => {
    setServerError('');
    try {
      // Save the message in MongoDB through the backend API
      await contactsApi.create({
        firstname: data.firstName,
        lastname: data.lastName,
        phone: data.contactNumber,
        email: data.email,
        message: data.message
      });
      reset();
      setSent(true);
      // Redirect user back to Home Page shortly after a successful submission
      setTimeout(() => navigate('/'), 2500);
    } catch (err) {
      setServerError(err.message);
    }
  };

  return (
    <div className="page-container contact-page">
      <h2>Contact Me</h2>

      {/* Actual Contact Panel Information */}
      <div className="contact-panel">
        <p><strong>Location:</strong> Hamilton, ON</p>
        <p><strong>Phone:</strong> (226) 552-3542</p>
        <p><strong>Email:</strong> kjames50@my.centennialcollege.ca</p>
        <p><strong>LinkedIn:</strong> linkedin.com/in/kaelyn-james</p>
      </div>

      {sent && <p className="alert alert-success">Thank you! Your message was sent. Redirecting to Home…</p>}
      {serverError && <p className="alert alert-error">{serverError}</p>}

      {/* Interactive Contact Form */}
      <form onSubmit={handleSubmit(onSubmit)} className="contact-form" noValidate>
        <div className="form-row">
          <div className="form-group">
            <label htmlFor="c-first">First Name:</label>
            <input id="c-first" {...register("firstName", { required: true })} />
            {errors.firstName && <span className="error">First Name is required</span>}
          </div>

          <div className="form-group">
            <label htmlFor="c-last">Last Name:</label>
            <input id="c-last" {...register("lastName", { required: true })} />
            {errors.lastName && <span className="error">Last Name is required</span>}
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="c-phone">Contact Number:</label>
            <input id="c-phone" type="tel" {...register("contactNumber", { required: true })} />
            {errors.contactNumber && <span className="error">Contact number is required</span>}
          </div>

          <div className="form-group">
            <label htmlFor="c-email">Email Address:</label>
            <input id="c-email" type="email" {...register("email", { required: true, pattern: /.+@.+\..+/ })} />
            {errors.email && <span className="error">Valid email address is required</span>}
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="c-msg">Message:</label>
          <textarea id="c-msg" {...register("message", { required: true })} />
          {errors.message && <span className="error">Message is required</span>}
        </div>

        <button type="submit" className="btn" disabled={isSubmitting}>
          {isSubmitting ? 'Sending…' : 'Send Message'}
        </button>
      </form>
    </div>
  );
}
