import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { useAuth } from '../auth/AuthContext';

export default function Signin() {
  const { signin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [serverError, setServerError] = useState('');
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm();

  const onSubmit = async (data) => {
    setServerError('');
    try {
      await signin(data);
      navigate(location.state?.from?.pathname || '/');
    } catch (err) {
      setServerError(err.message);
    }
  };

  return (
    <div className="page-container auth-page">
      <h2>Sign In</h2>
      <form onSubmit={handleSubmit(onSubmit)} className="contact-form" noValidate>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input id="email" type="email" {...register('email', { required: 'Email is required' })} />
          {errors.email && <span className="error">{errors.email.message}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input id="password" type="password" {...register('password', { required: 'Password is required' })} />
          {errors.password && <span className="error">{errors.password.message}</span>}
        </div>
        {serverError && <p className="alert alert-error">{serverError}</p>}
        <button type="submit" className="btn" disabled={isSubmitting}>
          {isSubmitting ? 'Signing in…' : 'Sign In'}
        </button>
      </form>
      <p className="auth-switch">No account yet? <Link to="/signup">Sign up</Link></p>
    </div>
  );
}
