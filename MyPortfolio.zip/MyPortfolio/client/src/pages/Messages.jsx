import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { contactsApi } from '../lib/api';
import useCrud from '../lib/useCrud';

// Admin-only page: full CRUD on Contact messages saved from the Contact form
function EditContact({ contact, onSave, onCancel }) {
  const { register, handleSubmit, formState: { errors } } = useForm({ defaultValues: contact });
  return (
    <form onSubmit={handleSubmit(onSave)} className="crud-form inline-edit" noValidate>
      <div className="form-row">
        <div className="form-group">
          <label>First Name:</label>
          <input {...register('firstname', { required: 'Required' })} />
          {errors.firstname && <span className="error">{errors.firstname.message}</span>}
        </div>
        <div className="form-group">
          <label>Last Name:</label>
          <input {...register('lastname', { required: 'Required' })} />
          {errors.lastname && <span className="error">{errors.lastname.message}</span>}
        </div>
      </div>
      <div className="form-row">
        <div className="form-group">
          <label>Email:</label>
          <input type="email" {...register('email', { required: 'Required' })} />
          {errors.email && <span className="error">{errors.email.message}</span>}
        </div>
        <div className="form-group">
          <label>Phone:</label>
          <input {...register('phone')} />
        </div>
      </div>
      <div className="form-group">
        <label>Message:</label>
        <textarea {...register('message')} />
      </div>
      <div className="form-actions">
        <button type="submit" className="btn btn-small">Save</button>
        <button type="button" className="btn btn-small btn-plain" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}

export default function Messages() {
  const { items, loading, error, update, remove, removeAll } = useCrud(contactsApi);
  const [editingId, setEditingId] = useState(null);
  const [notice, setNotice] = useState('');

  const save = async (data) => {
    const { firstname, lastname, email, phone, message } = data;
    if (await update(editingId, { firstname, lastname, email, phone, message })) {
      setEditingId(null);
      setNotice('Message updated.');
    }
  };

  const delAll = async () => {
    if (window.confirm('Delete ALL messages?') && await removeAll()) setNotice('All messages deleted.');
  };

  return (
    <div className="page-container messages-page">
      <h2>Contact Messages <span className="count">({items.length})</span></h2>
      {notice && <p className="alert alert-success">{notice}</p>}
      {error && <p className="alert alert-error">{error}</p>}
      {loading && <p>Loading…</p>}
      {!loading && items.length === 0 && <p>No messages yet.</p>}

      <div className="education-list">
        {items.map((c) => (
          <div key={c._id} className="education-card">
            {editingId === c._id ? (
              <EditContact contact={c} onSave={save} onCancel={() => setEditingId(null)} />
            ) : (
              <>
                <h3>{c.firstname} {c.lastname}</h3>
                <p className="meta">{c.email}{c.phone && ` · ${c.phone}`}{c.created && ` · ${new Date(c.created).toLocaleString('en-CA')}`}</p>
                {c.message && <p>{c.message}</p>}
                <div className="card-actions">
                  <button className="btn btn-small" onClick={() => setEditingId(c._id)}>Edit</button>
                  <button className="btn btn-small btn-danger"
                    onClick={async () => { if (await remove(c._id)) setNotice('Message deleted.'); }}>Delete</button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>

      {items.length > 0 && <button className="btn btn-danger delete-all" onClick={delAll}>Delete All Messages</button>}
    </div>
  );
}
