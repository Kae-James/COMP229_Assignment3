import React, { useState } from 'react';
import { projectsApi } from '../lib/api';
import useCrud from '../lib/useCrud';
import { useAuth } from '../auth/AuthContext';
import ProjectForm from '../components/ProjectForm';
import { toDisplayDate } from '../lib/format';

export default function Projects() {
  const { isAdmin } = useAuth();
  const { items, loading, error, create, update, remove, removeAll } = useCrud(projectsApi);
  const [editing, setEditing] = useState(null);
  const [notice, setNotice] = useState('');

  const save = async (data) => {
    const ok = editing ? await update(editing._id, data) : await create(data);
    if (ok) { setNotice(editing ? 'Project updated.' : 'Project added.'); setEditing(null); }
    return ok;
  };

  const del = async (p) => {
    if (await remove(p._id)) setNotice(`Deleted "${p.title}".`);
  };

  const delAll = async () => {
    if (window.confirm('Delete ALL projects?') && await removeAll()) setNotice('All projects deleted.');
  };

  return (
    <div className="page-container projects-page">
      <h2>Academic Projects</h2>

      {isAdmin && (
        <div className="admin-panel">
          <ProjectForm initial={editing} onSave={save} onCancel={() => setEditing(null)} />
        </div>
      )}

      {notice && <p className="alert alert-success">{notice}</p>}
      {error && <p className="alert alert-error">{error}</p>}
      {loading && <p>Loading…</p>}
      {!loading && items.length === 0 && <p>No projects yet.</p>}

      <div className="projects-grid">
        {items.map((p) => (
          <div key={p._id} className="project-card">
            <h3>{p.title}</h3>
            {p.technologies && <p><strong>Technologies:</strong> {p.technologies}</p>}
            {p.role && <p><strong>Role:</strong> {p.role}</p>}
            {p.completion && <p><strong>Completed:</strong> {toDisplayDate(p.completion)}</p>}
            {p.description && <p><strong>Outcome:</strong> {p.description}</p>}
            {isAdmin && (
              <div className="card-actions">
                <button className="btn btn-small" onClick={() => { setEditing(p); window.scrollTo(0, 0); }}>Edit</button>
                <button className="btn btn-small btn-danger" onClick={() => del(p)}>Delete</button>
              </div>
            )}
          </div>
        ))}
      </div>

      {isAdmin && items.length > 0 && (
        <button className="btn btn-danger delete-all" onClick={delAll}>Delete All Projects</button>
      )}
    </div>
  );
}
