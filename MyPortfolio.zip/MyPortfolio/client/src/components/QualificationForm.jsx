import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { toInputDate } from '../lib/format';

const empty = { title: '', firstname: '', lastname: '', email: '', completion: '', description: '' };

// Add / Edit form for an Education (Qualification) record
export default function QualificationForm({ initial, onSave, onCancel }) {
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm({ defaultValues: empty });

  useEffect(() => {
    reset(initial ? { ...empty, ...initial, completion: toInputDate(initial.completion) } : empty);
  }, [initial, reset]);

  const submit = async (data) => {
    const ok = await onSave({ ...data, completion: data.completion || undefined });
    if (ok) reset(empty);   // keep what was typed if the save failed
  };

  return (
    <form onSubmit={handleSubmit(submit)} className="crud-form" noValidate>
      <h3>{initial ? 'Edit Qualification' : 'Add Qualification'}</h3>
      <div className="form-group">
        <label htmlFor="q-title">Title:</label>
        <input id="q-title" {...register('title', { required: 'Title is required' })} />
        {errors.title && <span className="error">{errors.title.message}</span>}
      </div>
      <div className="form-row">
        <div className="form-group">
          <label htmlFor="q-first">First Name:</label>
          <input id="q-first" {...register('firstname')} />
        </div>
        <div className="form-group">
          <label htmlFor="q-last">Last Name:</label>
          <input id="q-last" {...register('lastname')} />
        </div>
      </div>
      <div className="form-row">
        <div className="form-group">
          <label htmlFor="q-email">Email:</label>
          <input id="q-email" type="email" {...register('email', {
            pattern: { value: /.+@.+\..+/, message: 'Please enter a valid email address' }
          })} />
          {errors.email && <span className="error">{errors.email.message}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="q-date">Completion Date:</label>
          <input id="q-date" type="date" {...register('completion')} />
        </div>
      </div>
      <div className="form-group">
        <label htmlFor="q-desc">Description:</label>
        <textarea id="q-desc" {...register('description')} />
      </div>
      <div className="form-actions">
        <button type="submit" className="btn" disabled={isSubmitting}>{initial ? 'Update' : 'Add'}</button>
        {initial && <button type="button" className="btn btn-plain" onClick={onCancel}>Cancel</button>}
      </div>
    </form>
  );
}
