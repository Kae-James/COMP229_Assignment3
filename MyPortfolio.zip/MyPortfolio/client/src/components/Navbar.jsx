import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import logo from '../assets/logo.png';
import { useAuth } from '../auth/AuthContext';

export default function Navbar() {
  const { user, isSignedIn, isAdmin, signout } = useAuth();
  const navigate = useNavigate();

  const handleSignout = async () => {
    await signout();
    navigate('/');
  };

  return (
    <nav className="navbar">
      <div className="navbar-logo">
        <Link to="/">
          <img src={logo} alt="Custom Portfolio Logo" className="site-logo" />
        </Link>
      </div>
      <ul className="nav-links">
        <li><Link to="/">Home</Link></li>
        <li><Link to="/about">About Me</Link></li>
        <li><Link to="/projects">Projects</Link></li>
        <li><Link to="/education">Education</Link></li>
        <li><Link to="/services">Services</Link></li>
        <li><Link to="/contact">Contact Me</Link></li>
        {isAdmin && <li><Link to="/messages">Messages</Link></li>}
        {!isSignedIn && <li><Link to="/signin">Sign In</Link></li>}
        {!isSignedIn && <li><Link to="/signup" className="nav-cta">Sign Up</Link></li>}
        {isSignedIn && (
          <li className="nav-user">
            <span className={`role-badge ${isAdmin ? 'admin' : ''}`}>{user.name} · {user.role}</span>
            <button type="button" className="link-btn" onClick={handleSignout}>Sign Out</button>
          </li>
        )}
      </ul>
    </nav>
  );
}
