import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { toInputDate } from '../lib/format';

const empty = { title: '', firstname: '', lastname: '', email: '', completion: '', technologies: '', role: '', description: '' };

// Add / Edit form for a Project record
export default function ProjectForm({ initial, onSave, onCancel }) {
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm({ defaultValues: empty });

  useEffect(() => {
    reset(initial ? { ...empty, ...initial, completion: toInputDate(initial.completion) } : empty);
  }, [initial, reset]);

  const submit = async (data) => {
    const ok = await onSave({ ...data, completion: data.completion || undefined });
    if (ok) reset(empty);   // keep what was typed if the save failed
  };

  return (
    <form onSubmit={handleSubmit(submit)} className="crud-form" noValidate>
      <h3>{initial ? 'Edit Project' : 'Add Project'}</h3>
      <div className="form-group">
        <label htmlFor="p-title">Title:</label>
        <input id="p-title" {...register('title', { required: 'Title is required' })} />
        {errors.title && <span className="error">{errors.title.message}</span>}
      </div>
      <div className="form-row">
        <div className="form-group">
          <label htmlFor="p-first">First Name:</label>
          <input id="p-first" {...register('firstname')} />
        </div>
        <div className="form-group">
          <label htmlFor="p-last">Last Name:</label>
          <input id="p-last" {...register('lastname')} />
        </div>
      </div>
      <div className="form-row">
        <div className="form-group">
          <label htmlFor="p-email">Email:</label>
          <input id="p-email" type="email" {...register('email', {
            pattern: { value: /.+@.+\..+/, message: 'Please enter a valid email address' }
          })} />
          {errors.email && <span className="error">{errors.email.message}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="p-date">Completion Date:</label>
          <input id="p-date" type="date" {...register('completion')} />
        </div>
      </div>
      <div className="form-row">
        <div className="form-group">
          <label htmlFor="p-tech">Technologies:</label>
          <input id="p-tech" {...register('technologies')} />
        </div>
        <div className="form-group">
          <label htmlFor="p-role">My Role:</label>
          <input id="p-role" {...register('role')} />
        </div>
      </div>
      <div className="form-group">
        <label htmlFor="p-desc">Description:</label>
        <textarea id="p-desc" {...register('description')} />
      </div>
      <div className="form-actions">
        <button type="submit" className="btn" disabled={isSubmitting}>{initial ? 'Update' : 'Add'}</button>
        {initial && <button type="button" className="btn btn-plain" onClick={onCancel}>Cancel</button>}
      </div>
    </form>
  );
}
