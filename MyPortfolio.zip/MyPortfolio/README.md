# Kaelyn James – Full Stack Portfolio (COMP229 Assignment 3)

React (Vite) frontend + Node/Express + MongoDB backend with JWT authentication and user roles.

## Run locally
```bash
npm run install-all        # installs server + client packages
cd client && npm run dev   # Vite on http://localhost:5173 + API on http://localhost:3000
```
Vite forwards `/api` and `/auth` calls to the backend (see `client/vite.config.js`).

## Accounts
| Role  | Email               | Password    |
|-------|---------------------|-------------|
| Admin | admin@portfolio.com | Admin@12345 |
| User  | created on the Sign Up page | chosen on sign up |

The Admin account is created in MongoDB on server start (`server/helpers/seed.js`, values in `config/config.js`).
Sign up always creates role `user`.

## Roles
* **User / visitor** – view Projects and Education, send a Contact message.
* **Admin** – full CRUD on Projects, Qualifications (Education) and Contact messages (Messages page), list users.

## API
| Method | URL | Access |
|---|---|---|
| POST | /auth/signin | public |
| GET | /auth/signout | public |
| POST | /api/users | public (sign up) |
| GET / DELETE | /api/users | admin |
| GET / PUT / DELETE | /api/users/:userId | owner or admin |
| GET | /api/projects, /api/projects/:id | public |
| POST / PUT / DELETE | /api/projects[/:id] | admin |
| GET | /api/qualifications, /api/qualifications/:id | public |
| POST / PUT / DELETE | /api/qualifications[/:id] | admin |
| POST | /api/contacts | public (Contact form) |
| GET / PUT / DELETE | /api/contacts[/:id] | admin |
