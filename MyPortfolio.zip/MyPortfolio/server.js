import config from './config/config.js'
import app from './server/express.js'
import mongoose from 'mongoose'
import { seedDatabase } from './server/helpers/seed.js'

mongoose.Promise = global.Promise
mongoose.connect(config.mongoUri)
  .then(async () => {
    console.log('Connected to the database!')
    await seedDatabase()   // make sure the hardcoded Admin account exists
  })
  .catch((err) => console.error('Database connection failed:', err.message))

mongoose.connection.on('error', () => {
  throw new Error(`unable to connect to database: ${config.mongoUri}`)
})

app.listen(config.port, (err) => {
  if (err) console.log(err)
  console.info('Server started on port %s.', config.port)
})

export default app
